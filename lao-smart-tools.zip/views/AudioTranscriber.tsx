import React, { useState, useRef } from 'react';
import { transcribeAudio } from '../services/geminiService';
import { Button } from '../components/Button';
import { Mic, Square, ArrowLeft, Loader2, Copy, Check, Upload } from 'lucide-react';

interface Props {
  onBack: () => void;
}

export const AudioTranscriber: React.FC<Props> = ({ onBack }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [transcription, setTranscription] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setAudioBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setTranscription('');
      setAudioBlob(null);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      alert("ບໍ່ສາມາດເຂົ້າເຖິງໄມໂຄຣໂຟນໄດ້ ກະລຸນາກວດສອບການອະນຸຍາດ");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAudioBlob(file);
      setTranscription('');
    }
  };

  const handleTranscribe = async () => {
    if (!audioBlob) return;
    setLoading(true);
    
    try {
      // Convert Blob to Base64
      const reader = new FileReader();
      reader.readAsDataURL(audioBlob);
      reader.onloadend = async () => {
        const base64data = reader.result as string;
        // Remove data URL prefix (e.g., "data:audio/webm;base64,")
        const base64Content = base64data.split(',')[1];
        const mimeType = audioBlob.type || 'audio/webm'; // Fallback if type is missing

        const result = await transcribeAudio(base64Content, mimeType);
        setTranscription(result);
        setLoading(false);
      };
    } catch (error) {
      console.error(error);
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!transcription) return;
    navigator.clipboard.writeText(transcription);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
      <div className="flex items-center space-x-4 mb-6">
        <Button variant="ghost" onClick={onBack} className="!p-2">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <Mic className="w-8 h-8 text-orange-500" />
            ຖອດຄວາມສຽງ (Audio Transcriber)
          </h1>
          <p className="text-gray-500">ແປງສຽງເວົ້າເປັນຂໍ້ຄວາມດ້ວຍ AI</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Input Control */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 flex flex-col items-center justify-center space-y-8 min-h-[400px]">
           
           <div className={`relative flex items-center justify-center w-32 h-32 rounded-full transition-all duration-500 ${isRecording ? 'bg-red-50 ring-4 ring-red-100' : 'bg-gray-50'}`}>
              {isRecording && (
                <div className="absolute inset-0 rounded-full border-4 border-red-400 animate-ping opacity-20"></div>
              )}
              {isRecording ? (
                <Mic className="w-12 h-12 text-red-500 animate-pulse" />
              ) : (
                <Mic className="w-12 h-12 text-gray-400" />
              )}
           </div>

           <div className="flex flex-col items-center gap-3 w-full max-w-xs">
              {!isRecording ? (
                <Button 
                  onClick={startRecording} 
                  className="w-full !bg-orange-500 hover:!bg-orange-600 !text-lg py-3"
                  icon={<Mic className="w-5 h-5" />}
                >
                  ເລີ່ມບັນທຶກສຽງ
                </Button>
              ) : (
                <Button 
                  onClick={stopRecording} 
                  variant="danger"
                  className="w-full !text-lg py-3"
                  icon={<Square className="w-5 h-5 fill-current" />}
                >
                  ຢຸດບັນທຶກ
                </Button>
              )}

              <div className="relative w-full">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-gray-200" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-white px-2 text-gray-500">ຫຼື</span>
                </div>
              </div>

              <input 
                type="file" 
                ref={fileInputRef}
                className="hidden"
                accept="audio/*"
                onChange={handleFileUpload}
              />
              <Button 
                variant="secondary" 
                className="w-full"
                onClick={() => fileInputRef.current?.click()}
                icon={<Upload className="w-4 h-4" />}
              >
                ອັບໂຫຼດໄຟລ໌ສຽງ
              </Button>
           </div>

           {audioBlob && (
             <div className="w-full bg-orange-50 p-4 rounded-lg border border-orange-100 animate-in fade-in slide-in-from-bottom-2">
               <p className="text-sm font-medium text-orange-800 mb-2 text-center">ພ້ອມສຳລັບຖອດຄວາມ</p>
               <audio controls src={URL.createObjectURL(audioBlob)} className="w-full h-8 mb-3" />
               <Button 
                 onClick={handleTranscribe} 
                 isLoading={loading}
                 className="w-full !bg-orange-600 hover:!bg-orange-700"
               >
                 ຖອດຄວາມດຽວນີ້
               </Button>
             </div>
           )}
        </div>

        {/* Output */}
        <div className="bg-orange-50/50 rounded-xl border border-orange-100 p-6 flex flex-col h-[500px] md:h-auto min-h-[400px] relative">
           <label className="text-sm font-semibold text-orange-900 mb-2">ຂໍ້ຄວາມທີ່ຖອດໄດ້</label>
           <div className="flex-1 overflow-y-auto bg-white rounded-lg p-4 text-gray-800 leading-relaxed whitespace-pre-line border border-orange-100 shadow-sm">
             {transcription ? transcription : (
               <div className="h-full flex flex-col items-center justify-center text-orange-300">
                 {loading ? (
                   <div className="text-center">
                      <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2 text-orange-500" />
                      <p className="text-orange-600">ກຳລັງຟັງ ແລະ ຖອດຄວາມ...</p>
                   </div>
                 ) : (
                   <>
                    <Mic className="w-12 h-12 mb-2 opacity-30" />
                    <p>ຂໍ້ຄວາມຈະປະກົດຢູ່ທີ່ນີ້</p>
                   </>
                 )}
               </div>
             )}
           </div>
           
           {transcription && (
             <div className="absolute top-6 right-6">
                <button 
                  onClick={handleCopy}
                  className="p-2 bg-white rounded-lg shadow-sm border border-gray-200 hover:bg-gray-50 text-gray-600 transition-all"
                  title="Copy"
                >
                  {copied ? <Check className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
                </button>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};
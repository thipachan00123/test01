import React, { useState, useRef } from 'react';
import { transcribeVideo } from '../services/geminiService';
import { Button } from '../components/Button';
import { Video, ArrowLeft, Loader2, Copy, Check, Upload, Languages } from 'lucide-react';

interface Props {
  onBack: () => void;
}

export const VideoTranscriber: React.FC<Props> = ({ onBack }) => {
  const [videoFile, setVideoFile] = useState<{data: string, mimeType: string, url: string, name: string} | null>(null);
  const [transcription, setTranscription] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [targetLang, setTargetLang] = useState('Lao'); // Default to Lao
  const fileInputRef = useRef<HTMLInputElement>(null);

  const languages = [
    { code: 'Original', label: 'ຕົ້ນສະບັບ (Original)' },
    { code: 'Lao', label: 'ລາວ (Lao)' },
    { code: 'Thai', label: 'ໄທ (Thai)' },
    { code: 'English', label: 'ອັງກິດ (English)' },
    { code: 'Japanese', label: 'ຍີ່ປຸ່ນ (Japanese)' },
    { code: 'Chinese', label: 'ຈີນ (Chinese)' },
    { code: 'Korean', label: 'ເກົາຫຼີ (Korean)' },
    { code: 'French', label: 'ຝຣັ່ງ (French)' },
    { code: 'German', label: 'ເຢຍລະມັນ (German)' },
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setVideoFile({
          data: base64String,
          mimeType: file.type,
          url: url,
          name: file.name
        });
        setTranscription('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleTranscribe = async () => {
    if (!videoFile) return;
    setLoading(true);
    setTranscription('');
    
    try {
      const result = await transcribeVideo(videoFile.data, videoFile.mimeType, targetLang);
      setTranscription(result);
    } catch (error) {
      console.error(error);
      setTranscription("ເກີດຂໍ້ຜິດພາດ ກະລຸນາລອງໃໝ່ອີກຄັ້ງ");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!transcription) return;
    navigator.clipboard.writeText(transcription);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-6 space-y-6">
      <div className="flex items-center space-x-4 mb-6">
        <Button variant="ghost" onClick={onBack} className="!p-2">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <Video className="w-8 h-8 text-pink-600" />
            ຖອດຄວາມວິດີໂອ (Video Transcriber)
          </h1>
          <p className="text-gray-500">ແປງສຽງຈາກວິດີໂອເປັນຂໍ້ຄວາມ ແລະ ແປພາສາໄດ້ທັນທີ</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Control */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 flex flex-col space-y-6">
           
           <div className="w-full bg-gray-50 rounded-lg border-2 border-dashed border-gray-300 min-h-[250px] flex flex-col items-center justify-center p-4 relative overflow-hidden">
              {videoFile ? (
                <div className="w-full h-full flex flex-col items-center">
                   <video 
                     controls 
                     src={videoFile.url} 
                     className="max-h-[300px] w-full rounded-lg shadow-sm mb-4 bg-black" 
                   />
                   <div className="flex justify-between w-full items-center px-2">
                     <span className="text-sm text-gray-600 truncate max-w-[200px]">{videoFile.name}</span>
                     <button 
                       onClick={() => {
                         setVideoFile(null);
                         setTranscription('');
                         if (fileInputRef.current) fileInputRef.current.value = '';
                       }}
                       className="text-xs text-red-500 hover:text-red-700 font-medium"
                     >
                       ລົບວິດີໂອ
                     </button>
                   </div>
                </div>
              ) : (
                <div className="text-center p-6">
                  <div className="bg-pink-50 p-4 rounded-full inline-flex mb-4">
                    <Video className="w-8 h-8 text-pink-400" />
                  </div>
                  <p className="text-gray-600 font-medium mb-1">ຄິກເພື່ອອັບໂຫຼດວິດີໂອ</p>
                  <p className="text-gray-400 text-sm">ຮອງຮັບ MP4, WebM, MOV (ສູງສຸດ ~20MB)</p>
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    accept="video/*"
                    onChange={handleFileUpload}
                  />
                </div>
              )}
           </div>

           <div className="space-y-4">
              <div>
                <label className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <Languages className="w-4 h-4" /> ພາສາປາຍທາງ (Output Language)
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => setTargetLang(lang.code)}
                      className={`px-3 py-2 rounded-lg text-sm font-medium border transition-all ${
                        targetLang === lang.code 
                          ? 'bg-pink-50 border-pink-500 text-pink-700 shadow-sm' 
                          : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      {lang.label.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>

              <Button 
                onClick={handleTranscribe} 
                isLoading={loading}
                disabled={!videoFile}
                className="w-full !bg-pink-600 hover:!bg-pink-700 !text-lg py-3"
                icon={<Upload className="w-5 h-5" />}
              >
                {loading ? 'ກຳລັງປະມວນຜົນວິດີໂອ...' : 'ເລີ່ມຖອດຄວາມ ແລະ ແປ'}
              </Button>
           </div>
        </div>

        {/* Output */}
        <div className="bg-pink-50/50 rounded-xl border border-pink-100 p-6 flex flex-col min-h-[500px] relative">
           <label className="text-sm font-semibold text-pink-900 mb-2 flex justify-between items-center">
             <span>ຜົນລັບ ({targetLang})</span>
             {transcription && (
               <span className="text-xs font-normal text-pink-600 bg-pink-100 px-2 py-0.5 rounded-full">
                 AI Translated
               </span>
             )}
           </label>
           <div className="flex-1 overflow-y-auto bg-white rounded-lg p-6 text-gray-800 leading-relaxed whitespace-pre-line border border-pink-100 shadow-sm">
             {transcription ? transcription : (
               <div className="h-full flex flex-col items-center justify-center text-pink-300">
                 {loading ? (
                   <div className="text-center">
                      <Loader2 className="w-10 h-10 animate-spin mx-auto mb-4 text-pink-500" />
                      <p className="text-pink-600 font-medium">ກຳລັງເບິ່ງວິດີໂອ ແລະ ຖອດຄວາມ...</p>
                      <p className="text-pink-400 text-sm mt-1">ວິດີໂອຂະໜາດຍາວອາດໃຊ້ເວລາຈັກໜ້ອຍ</p>
                   </div>
                 ) : (
                   <>
                    <Video className="w-12 h-12 mb-3 opacity-30" />
                    <p>ຂໍ້ຄວາມຈາກການຖອດຄວາມຈະປະກົດຢູ່ທີ່ນີ້</p>
                   </>
                 )}
               </div>
             )}
           </div>
           
           {transcription && (
             <div className="absolute top-6 right-6">
                <button 
                  onClick={handleCopy}
                  className="p-2 bg-white rounded-lg shadow-sm border border-gray-200 hover:bg-gray-50 text-gray-600 transition-all"
                  title="Copy"
                >
                  {copied ? <Check className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
                </button>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};
import React, { useState } from 'react';
import { summarizeText } from '../services/geminiService';
import { Button } from '../components/Button';
import { FileText, AlignLeft, List, AlignJustify, ArrowLeft, Copy, Check, Sparkles } from 'lucide-react';

interface Props {
  onBack: () => void;
}

export const Summarizer: React.FC<Props> = ({ onBack }) => {
  const [inputText, setInputText] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'short' | 'bullet' | 'detail'>('short');
  const [useThinking, setUseThinking] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSummarize = async () => {
    if (!inputText.trim()) return;
    setLoading(true);
    setResult('');
    try {
      const summary = await summarizeText(inputText, mode, useThinking);
      setResult(summary);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
      <div className="flex items-center space-x-4 mb-6">
        <Button variant="ghost" onClick={onBack} className="!p-2">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <FileText className="w-8 h-8 text-indigo-600" />
            ຫຍໍ້ຄວາມ (Summarizer)
          </h1>
          <p className="text-gray-500">ຫຍໍ້ບົດຄວາມຍາວໆ ໃຫ້ເຂົ້າໃຈງ່າຍດ້ວຍ AI</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Input Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 flex flex-col h-[500px]">
          <div className="flex justify-between items-center mb-2">
            <label className="text-sm font-semibold text-gray-700">ຂໍ້ຄວາມຕົ້ນສະບັບ</label>
             <button 
               onClick={() => setUseThinking(!useThinking)}
               className={`flex items-center gap-1.5 px-2 py-1 rounded-full text-[10px] font-medium transition-all border ${useThinking ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-gray-50 border-gray-200 text-gray-500'}`}
             >
               <Sparkles className={`w-3 h-3 ${useThinking ? 'fill-indigo-400 text-indigo-500' : ''}`} />
               Deep Think
             </button>
          </div>
          <textarea
            className="flex-1 w-full p-4 border border-gray-200 rounded-lg resize-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-all text-gray-700"
            placeholder="ວາງຂໍ້ຄວາມທີ່ຕ້ອງການຫຍໍ້ ທີ່ນີ້..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
          />
          <div className="mt-4 space-y-3">
            <div className="flex gap-2 justify-center bg-gray-100 p-1 rounded-lg">
              <button
                onClick={() => setMode('short')}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-all flex items-center justify-center gap-2 ${mode === 'short' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <AlignLeft className="w-4 h-4" /> ສັ້ນກະທັດຮັດ
              </button>
              <button
                onClick={() => setMode('bullet')}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-all flex items-center justify-center gap-2 ${mode === 'bullet' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <List className="w-4 h-4" /> ເປັນຂໍ້ໆ
              </button>
              <button
                onClick={() => setMode('detail')}
                className={`flex-1 py-2 text-sm font-medium rounded-md transition-all flex items-center justify-center gap-2 ${mode === 'detail' ? 'bg-white text-indigo-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
              >
                <AlignJustify className="w-4 h-4" /> ລະອຽດ
              </button>
            </div>
            <Button 
              onClick={handleSummarize} 
              isLoading={loading} 
              disabled={!inputText.trim()}
              className="w-full"
            >
              ເລີ່ມການຫຍໍ້ຄວາມ
            </Button>
          </div>
        </div>

        {/* Output Section */}
        <div className="bg-indigo-50 rounded-xl border border-indigo-100 p-6 flex flex-col h-[500px] relative">
           <label className="text-sm font-semibold text-indigo-900 mb-2">ຜົນລັບຈາກ AI</label>
           <div className="flex-1 overflow-y-auto bg-white/60 rounded-lg p-4 text-gray-800 leading-relaxed whitespace-pre-line border border-indigo-100/50">
             {result ? result : (
               <div className="h-full flex flex-col items-center justify-center text-indigo-300">
                 <FileText className="w-12 h-12 mb-2 opacity-50" />
                 <p>ຜົນລັບຈະສະແດງຢູ່ທີ່ນີ້</p>
               </div>
             )}
           </div>
           
           {result && (
             <div className="absolute top-6 right-6">
                <button 
                  onClick={handleCopy}
                  className="p-2 bg-white rounded-lg shadow-sm border border-gray-200 hover:bg-gray-50 text-gray-600 transition-all"
                  title="Copy"
                >
                  {copied ? <Check className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
                </button>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};
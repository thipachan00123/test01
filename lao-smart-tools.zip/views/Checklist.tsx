import React, { useState, useEffect } from 'react';
import { Button } from '../components/Button';
import { TodoItem } from '../types';
import { generateChecklist } from '../services/geminiService';
import { CheckSquare, Plus, Trash2, ArrowLeft, Wand2, Check } from 'lucide-react';

interface Props {
  onBack: () => void;
}

export const Checklist: React.FC<Props> = ({ onBack }) => {
  const [todos, setTodos] = useState<TodoItem[]>(() => {
    const saved = localStorage.getItem('thai_smart_tools_todos');
    return saved ? JSON.parse(saved) : [];
  });
  const [newTodo, setNewTodo] = useState('');
  const [aiTopic, setAiTopic] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [showAiInput, setShowAiInput] = useState(false);

  useEffect(() => {
    localStorage.setItem('thai_smart_tools_todos', JSON.stringify(todos));
  }, [todos]);

  const addTodo = (text: string) => {
    if (!text.trim()) return;
    const newItem: TodoItem = {
      id: crypto.randomUUID(),
      text,
      completed: false
    };
    setTodos([newItem, ...todos]);
    setNewTodo('');
  };

  const toggleTodo = (id: string) => {
    setTodos(todos.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const removeTodo = (id: string) => {
    setTodos(todos.filter(t => t.id !== id));
  };

  const handleAiGenerate = async () => {
    if (!aiTopic.trim()) return;
    setIsAiLoading(true);
    try {
      const generatedItems = await generateChecklist(aiTopic);
      // Merge with existing but put new ones on top
      setTodos([...generatedItems, ...todos]);
      setAiTopic('');
      setShowAiInput(false);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
      <div className="flex items-center space-x-4 mb-6">
        <Button variant="ghost" onClick={onBack} className="!p-2">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <CheckSquare className="w-8 h-8 text-rose-500" />
            ລາຍການທີ່ຕ້ອງເຮັດ (Checklist)
          </h1>
          <p className="text-gray-500">ຈັດການວຽກທີ່ຕ້ອງເຮັດ ຫຼື ໃຫ້ AI ຊ່ວຍວາງແຜນ</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden min-h-[600px] flex flex-col">
        {/* Input Area */}
        <div className="p-6 bg-rose-50 border-b border-rose-100 space-y-4">
          <div className="flex gap-3">
             <input
               type="text"
               value={newTodo}
               onChange={(e) => setNewTodo(e.target.value)}
               onKeyDown={(e) => e.key === 'Enter' && addTodo(newTodo)}
               className="flex-1 px-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-rose-500 focus:outline-none shadow-sm"
               placeholder="ເພີ່ມລາຍການໃໝ່..."
             />
             <Button onClick={() => addTodo(newTodo)} variant="primary" className="!bg-rose-500 hover:!bg-rose-600">
               <Plus className="w-5 h-5" />
             </Button>
          </div>

          {/* AI Helper Toggle */}
          {!showAiInput ? (
            <button 
              onClick={() => setShowAiInput(true)}
              className="text-sm text-rose-600 font-medium flex items-center hover:underline"
            >
              <Wand2 className="w-4 h-4 mr-2" />
              ຄິດບໍ່ອອກ? ໃຫ້ AI ຊ່ວຍສ້າງລາຍການ
            </button>
          ) : (
            <div className="bg-white p-4 rounded-lg border border-rose-200 shadow-sm animate-in fade-in slide-in-from-top-2">
               <label className="block text-sm font-medium text-gray-700 mb-2">
                 ຕ້ອງການເຮັດຫຍັງ? (ເຊັ່ນ: "ຈັດກະເປົາໄປທ່ຽວວັງວຽງ 3 ວັນ")
               </label>
               <div className="flex gap-2">
                 <input
                   type="text"
                   value={aiTopic}
                   onChange={(e) => setAiTopic(e.target.value)}
                   onKeyDown={(e) => e.key === 'Enter' && handleAiGenerate()}
                   className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-rose-500 focus:outline-none"
                   placeholder="ລະບຸຫົວຂໍ້..."
                 />
                 <Button 
                   onClick={handleAiGenerate} 
                   isLoading={isAiLoading}
                   className="!bg-gradient-to-r !from-rose-500 !to-orange-500 text-white"
                   icon={<Wand2 className="w-4 h-4"/>}
                 >
                   ສ້າງ
                 </Button>
               </div>
               <button 
                 onClick={() => setShowAiInput(false)}
                 className="text-xs text-gray-400 mt-2 hover:text-gray-600"
               >
                 ຍົກເລີກ
               </button>
            </div>
          )}
        </div>

        {/* List Area */}
        <div className="flex-1 p-2 md:p-6 overflow-y-auto">
           {todos.length === 0 ? (
             <div className="h-full flex flex-col items-center justify-center text-gray-400 opacity-60">
               <CheckSquare className="w-16 h-16 mb-4" />
               <p className="text-lg">ຍັງບໍ່ມີລາຍການ</p>
               <p className="text-sm">ເລີ່ມເພີ່ມວຽກທຳອິດຂອງທ່ານເລີຍ</p>
             </div>
           ) : (
             <ul className="space-y-2">
               {todos.map(todo => (
                 <li 
                   key={todo.id}
                   className={`group flex items-center p-3 rounded-lg border transition-all duration-200 ${todo.completed ? 'bg-gray-50 border-gray-100' : 'bg-white border-gray-200 hover:border-rose-300 hover:shadow-sm'}`}
                 >
                   <button 
                     onClick={() => toggleTodo(todo.id)}
                     className={`w-6 h-6 rounded-full border-2 flex items-center justify-center mr-4 transition-colors ${todo.completed ? 'bg-green-500 border-green-500' : 'border-gray-300 hover:border-rose-400'}`}
                   >
                     {todo.completed && <Check className="w-3.5 h-3.5 text-white" />}
                   </button>
                   
                   <span className={`flex-1 text-gray-700 ${todo.completed ? 'line-through text-gray-400' : ''}`}>
                     {todo.text}
                   </span>
                   
                   <button 
                     onClick={() => removeTodo(todo.id)}
                     className="opacity-0 group-hover:opacity-100 p-2 text-gray-400 hover:text-red-500 transition-all"
                   >
                     <Trash2 className="w-5 h-5" />
                   </button>
                 </li>
               ))}
             </ul>
           )}
        </div>

        {todos.length > 0 && (
          <div className="p-4 border-t border-gray-100 text-sm text-gray-500 flex justify-between bg-gray-50">
             <span>{todos.filter(t => !t.completed).length} ລາຍການຄົງເຫຼືອ</span>
             {todos.some(t => t.completed) && (
               <button 
                onClick={() => setTodos(todos.filter(t => !t.completed))}
                className="text-rose-500 hover:text-rose-700 font-medium"
               >
                 ລົບລາຍການທີ່ເຮັດແລ້ວ
               </button>
             )}
          </div>
        )}
      </div>
    </div>
  );
};
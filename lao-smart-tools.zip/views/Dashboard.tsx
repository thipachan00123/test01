import React from 'react';
import { AppView } from '../types';
import { RefreshCw, FileText, Calculator, CheckSquare, Mic, Video } from 'lucide-react';

interface Props {
  onNavigate: (view: AppView) => void;
}

export const Dashboard: React.FC<Props> = ({ onNavigate }) => {
  const tools = [
    {
      id: AppView.CONVERTER,
      title: 'ແປງຂໍ້ມູນ (Converter)',
      desc: 'ແປງໄຟລ໌ PDF, ຮູບພາບ, ຂໍ້ຄວາມ ຫຼື ໂຄດ ພ້ອມ Thinking Mode',
      icon: <RefreshCw className="w-8 h-8 text-blue-500" />,
      color: 'hover:border-blue-300 hover:bg-blue-50/50',
      delay: 'delay-0'
    },
    {
      id: AppView.VIDEO_TRANSCRIBER,
      title: 'ຖອດຄວາມວິດີໂອ (Video)',
      desc: 'ຖອດສຽງຈາກວິດີໂອເປັນຂໍ້ຄວາມ ພ້ອມແປພາສາອັດຕະໂນມັດ',
      icon: <Video className="w-8 h-8 text-pink-500" />,
      color: 'hover:border-pink-300 hover:bg-pink-50/50',
      delay: 'delay-75'
    },
    {
      id: AppView.SUMMARIZER,
      title: 'ຫຍໍ້ຄວາມ (Summarizer)',
      desc: 'ຫຍໍ້ບົດຄວາມຍາວໆ ໃຫ້ເຫຼືອພຽງໃຈຄວາມສຳຄັນ',
      icon: <FileText className="w-8 h-8 text-indigo-500" />,
      color: 'hover:border-indigo-300 hover:bg-indigo-50/50',
      delay: 'delay-100'
    },
    {
      id: AppView.AUDIO_TRANSCRIBER,
      title: 'ຖອດຄວາມສຽງ (Audio)',
      desc: 'ແປງສຽງເວົ້າເປັນຂໍ້ຄວາມ ຮອງຮັບພາສາລາວ (Speech to Text)',
      icon: <Mic className="w-8 h-8 text-orange-500" />,
      color: 'hover:border-orange-300 hover:bg-orange-50/50',
      delay: 'delay-200'
    },
    {
      id: AppView.GPA_CALCULATOR,
      title: 'ຄິດໄລ່ຄະແນນ (GPA)',
      desc: 'ເຄື່ອງມືຄິດໄລ່ຄະແນນສະເລ່ຍສະສົມ ຖືກຕ້ອງ ໃຊ້ງ່າຍ',
      icon: <Calculator className="w-8 h-8 text-teal-500" />,
      color: 'hover:border-teal-300 hover:bg-teal-50/50',
      delay: 'delay-300'
    },
    {
      id: AppView.CHECKLIST,
      title: 'ລາຍການທີ່ຕ້ອງເຮັດ (Checklist)',
      desc: 'ຈັດການສິ່ງທີ່ຕ້ອງເຮັດ ພ້ອມ AI ຊ່ວຍວາງແຜນງານ',
      icon: <CheckSquare className="w-8 h-8 text-rose-500" />,
      color: 'hover:border-rose-300 hover:bg-rose-50/50',
      delay: 'delay-500'
    }
  ];

  return (
    <div className="max-w-6xl mx-auto p-6 md:py-12">
      <div className="text-center mb-12 space-y-4">
        <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-rose-500 pb-1">
          Lao Smart Tools
        </h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tools.map((tool) => (
          <button
            key={tool.id}
            onClick={() => onNavigate(tool.id)}
            className={`group flex items-start p-6 bg-white rounded-2xl shadow-sm border border-gray-200 transition-all duration-300 hover:shadow-lg transform hover:-translate-y-1 ${tool.color} animate-in fade-in slide-in-from-bottom-4 ${tool.delay} fill-mode-backwards`}
          >
            <div className="p-3 bg-gray-50 rounded-xl mr-5 group-hover:scale-110 transition-transform duration-300 border border-gray-100 flex-shrink-0">
              {tool.icon}
            </div>
            <div className="text-left">
              <h3 className="text-xl font-bold text-gray-800 mb-2 group-hover:text-gray-900">
                {tool.title}
              </h3>
              <p className="text-gray-500 leading-relaxed text-sm">
                {tool.desc}
              </p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};
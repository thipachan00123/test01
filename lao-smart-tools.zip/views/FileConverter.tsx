import React, { useState, useRef } from 'react';
import { convertContent } from '../services/geminiService';
import { Button } from '../components/Button';
import { FileCode, ArrowLeft, ArrowRight, RefreshCw, Copy, Check, FileUp, Sparkles, Download, FileText } from 'lucide-react';

interface Props {
  onBack: () => void;
}

export const FileConverter: React.FC<Props> = ({ onBack }) => {
  const [inputContent, setInputContent] = useState('');
  const [instruction, setInstruction] = useState('');
  const [result, setResult] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [useThinking, setUseThinking] = useState(false);
  const [selectedFile, setSelectedFile] = useState<{name: string, data: string, mimeType: string} | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Preset instructions
  const presets = [
    { label: 'PDF to Word', prompt: 'Extract content from this file and format it as HTML suitable for a Word document. Maintain headers, tables, and lists. (Content in Lao/English)' },
    { label: 'JSON to CSV', prompt: 'Convert this JSON to CSV format.' },
    { label: 'Eng to Lao', prompt: 'Translate this text to Lao language.' },
    { label: 'Fix Grammar', prompt: 'Correct grammatical errors in this text.' },
    { label: 'Explain Code', prompt: 'Explain what this code does in detail (in Lao).' },
  ];

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        setSelectedFile({
          name: file.name,
          data: base64String,
          mimeType: file.type
        });
        // Clear text input if file is uploaded to avoid confusion, or keep both? 
        // Let's keep it clean.
        setInputContent('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleConvert = async () => {
    if ((!inputContent.trim() && !selectedFile) || !instruction.trim()) return;
    setLoading(true);
    setResult('');
    try {
      const fileData = selectedFile ? { data: selectedFile.data, mimeType: selectedFile.mimeType } : null;
      const converted = await convertContent(inputContent, fileData, instruction, useThinking);
      setResult(converted);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadWord = () => {
    if (!result) return;
    // Create a Blob with HTML content and Word MIME type
    const header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><title>Export HTML To Doc</title></head><body>";
    const footer = "</body></html>";
    const sourceHTML = header + result + footer;
    
    const blob = new Blob(['\ufeff', sourceHTML], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `converted_${selectedFile ? selectedFile.name.split('.')[0] : 'document'}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Check if current instruction looks like a Word export
  const isWordExport = instruction.toLowerCase().includes('word') || instruction.toLowerCase().includes('doc');

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-6 space-y-6">
      <div className="flex items-center space-x-4 mb-6">
        <Button variant="ghost" onClick={onBack} className="!p-2">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <RefreshCw className="w-8 h-8 text-blue-600" />
            ແປງຂໍ້ມູນອັດສະລິຍະ (Smart Converter)
          </h1>
          <p className="text-gray-500">ແປງໄຟລ໌ PDF, ຮູບພາບ, ຂໍ້ຄວາມ ຫຼື ໂຄດດ້ວຍ AI</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 min-h-[600px]">
        
        {/* Input Panel */}
        <div className="flex flex-col gap-4 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex justify-between items-start">
             <div>
               <label className="text-sm font-semibold text-gray-700 block">ຂໍ້ມູນນຳເຂົ້າ (Input)</label>
               <span className="text-xs text-gray-400">ຮອງຮັບຂໍ້ຄວາມ, PDF, ຮູບພາບ, ໂຄດ</span>
             </div>
             
             {/* Thinking Toggle */}
             <button 
               onClick={() => setUseThinking(!useThinking)}
               className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${useThinking ? 'bg-indigo-50 border-indigo-200 text-indigo-700' : 'bg-gray-50 border-gray-200 text-gray-500'}`}
             >
               <Sparkles className={`w-3 h-3 ${useThinking ? 'fill-indigo-400 text-indigo-500' : ''}`} />
               Deep Think {useThinking ? 'ເປີດ' : 'ປິດ'}
             </button>
          </div>
          
          {!selectedFile ? (
             <textarea
              className="flex-1 w-full p-4 border border-gray-200 rounded-lg resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none font-mono text-sm bg-gray-50"
              placeholder="ວາງຂໍ້ຄວາມ ຫຼື ໂຄດ ທີ່ນີ້..."
              value={inputContent}
              onChange={(e) => setInputContent(e.target.value)}
            />
          ) : (
            <div className="flex-1 w-full bg-blue-50 border border-blue-100 rounded-lg flex flex-col items-center justify-center relative p-6">
               <FileText className="w-16 h-16 text-blue-300 mb-2" />
               <p className="font-medium text-blue-800 truncate max-w-full px-4">{selectedFile.name}</p>
               <p className="text-xs text-blue-500">{selectedFile.mimeType}</p>
               <button 
                 onClick={() => setSelectedFile(null)}
                 className="absolute top-2 right-2 p-1 bg-white rounded-full text-gray-400 hover:text-red-500 shadow-sm"
               >
                 <ArrowLeft className="w-4 h-4" />
               </button>
            </div>
          )}

          <div className="flex items-center gap-2">
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleFileSelect} 
              className="hidden" 
              accept=".pdf,.txt,.js,.ts,.py,.html,.css,.json,.csv,image/*"
            />
            {!selectedFile && (
              <Button 
                variant="secondary" 
                onClick={() => fileInputRef.current?.click()}
                className="text-xs py-1.5"
                icon={<FileUp className="w-3 h-3" />}
              >
                ອັບໂຫຼດໄຟລ໌
              </Button>
            )}
             <span className="text-xs text-gray-400 ml-auto">
               {useThinking ? 'ໃຊ້ Gemini 3 Pro (ສະຫຼາດກວ່າ)' : 'ໃຊ້ Gemini 3 Flash (ໄວ)'}
             </span>
          </div>

          <div className="space-y-3 pt-2 border-t border-gray-100">
            <label className="text-sm font-semibold text-gray-700 block mt-2">ຕ້ອງການເຮັດຫຍັງ?</label>
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin">
              {presets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => setInstruction(preset.prompt)}
                  className="px-3 py-1.5 bg-gray-100 hover:bg-gray-200 rounded-full text-xs text-gray-700 whitespace-nowrap transition-colors"
                >
                  {preset.label}
                </button>
              ))}
            </div>
            <div className="flex gap-3">
              <input 
                type="text" 
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                placeholder="ພິມຄຳສັ່ງເອງ (ເຊັ່ນ 'ແປເປັນພາສາລາວ')..."
                value={instruction}
                onChange={(e) => setInstruction(e.target.value)}
              />
              <Button 
                onClick={handleConvert} 
                isLoading={loading}
                disabled={(!inputContent.trim() && !selectedFile) || !instruction.trim()}
                className="!bg-blue-600 hover:!bg-blue-700 min-w-[120px]"
              >
                ແປງຂໍ້ມູນ
              </Button>
            </div>
          </div>
        </div>

        {/* Output Panel */}
        <div className="flex flex-col gap-4 bg-slate-900 rounded-xl shadow-lg border border-slate-800 p-6 text-slate-100">
           <div className="flex justify-between items-center">
             <label className="text-sm font-semibold text-slate-400">ຜົນລັບ (Output)</label>
             <div className="flex gap-2">
               {result && isWordExport && (
                 <button
                   onClick={handleDownloadWord}
                   className="flex items-center gap-1 text-xs px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-md transition-colors"
                 >
                   <Download className="w-3 h-3" />
                   ດາວໂຫຼດ Word
                 </button>
               )}
               {result && (
                 <button 
                    onClick={handleCopy}
                    className="flex items-center gap-1 text-xs px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-md transition-colors"
                  >
                    {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                    {copied ? 'ຄັດລອກແລ້ວ' : 'ຄັດລອກ'}
                  </button>
               )}
             </div>
           </div>

           <div className="flex-1 w-full p-4 bg-slate-950 rounded-lg overflow-auto font-mono text-sm border border-slate-800/50">
             {result ? (
               <div className="whitespace-pre-wrap break-words">{result}</div>
             ) : (
               <div className="h-full flex flex-col items-center justify-center text-slate-600">
                 <ArrowRight className="w-8 h-8 mb-2 opacity-50" />
                 <p>ຜົນລັບຈະປະກົດຢູ່ທີ່ນີ້</p>
               </div>
             )}
           </div>
        </div>

      </div>
    </div>
  );
};
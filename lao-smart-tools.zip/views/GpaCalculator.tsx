import React, { useState, useEffect } from 'react';
import { Button } from '../components/Button';
import { GpaSubject, GradeValue } from '../types';
import { Calculator, Plus, Trash2, ArrowLeft, RotateCcw } from 'lucide-react';

interface Props {
  onBack: () => void;
}

export const GpaCalculator: React.FC<Props> = ({ onBack }) => {
  const [subjects, setSubjects] = useState<GpaSubject[]>([
    { id: '1', name: 'ວິຊາທີ 1', credit: 3, grade: 4.0 },
    { id: '2', name: 'ວິຊາທີ 2', credit: 3, grade: 3.5 },
    { id: '3', name: 'ວິຊາທີ 3', credit: 3, grade: 3.0 },
  ]);
  const [gpa, setGpa] = useState<string>('0.00');

  useEffect(() => {
    calculateGpa();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [subjects]);

  const calculateGpa = () => {
    let totalPoints = 0;
    let totalCredits = 0;

    subjects.forEach(sub => {
      totalPoints += sub.grade * sub.credit;
      totalCredits += sub.credit;
    });

    if (totalCredits === 0) {
      setGpa('0.00');
    } else {
      setGpa((totalPoints / totalCredits).toFixed(2));
    }
  };

  const addSubject = () => {
    setSubjects([
      ...subjects,
      { id: crypto.randomUUID(), name: `ວິຊາທີ ${subjects.length + 1}`, credit: 3, grade: 4.0 }
    ]);
  };

  const removeSubject = (id: string) => {
    setSubjects(subjects.filter(s => s.id !== id));
  };

  const updateSubject = (id: string, field: keyof GpaSubject, value: any) => {
    setSubjects(subjects.map(s => 
      s.id === id ? { ...s, [field]: value } : s
    ));
  };

  const reset = () => {
    setSubjects([{ id: crypto.randomUUID(), name: 'ວິຊາທີ 1', credit: 3, grade: 4.0 }]);
  };

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6 space-y-6">
       <div className="flex items-center space-x-4 mb-6">
        <Button variant="ghost" onClick={onBack} className="!p-2">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
            <Calculator className="w-8 h-8 text-teal-600" />
            ຄິດໄລ່ຄະແນນ (GPA Calculator)
          </h1>
          <p className="text-gray-500">ຄິດໄລ່ຄະແນນສະເລ່ຍສະສົມໄດ້ງ່າຍໆ</p>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-6">
        {/* Main Table */}
        <div className="flex-1 bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="p-4 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
            <h2 className="font-semibold text-gray-700">ລາຍການວິຊາ</h2>
            <Button variant="ghost" onClick={reset} className="text-sm text-red-500 hover:text-red-700 hover:bg-red-50">
              <RotateCcw className="w-4 h-4 mr-1" /> ລີເຊັດ
            </Button>
          </div>
          
          <div className="p-4 space-y-4">
            {subjects.map((subject, index) => (
              <div key={subject.id} className="flex flex-col md:flex-row gap-3 items-start md:items-center bg-white p-3 rounded-lg border border-gray-100 hover:border-teal-200 transition-colors">
                <div className="flex-1 w-full">
                  <input
                    type="text"
                    value={subject.name}
                    onChange={(e) => updateSubject(subject.id, 'name', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-200 rounded-md focus:ring-2 focus:ring-teal-500 focus:outline-none"
                    placeholder="ຊື່ວິຊາ"
                  />
                </div>
                <div className="flex w-full md:w-auto gap-3">
                  <div className="flex-1 md:w-24">
                     <select
                      value={subject.credit}
                      onChange={(e) => updateSubject(subject.id, 'credit', Number(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-200 rounded-md focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white"
                     >
                       {[1, 1.5, 2, 2.5, 3, 3.5, 4].map(c => (
                         <option key={c} value={c}>{c} ໜ່ວຍກິດ</option>
                       ))}
                     </select>
                  </div>
                  <div className="flex-1 md:w-32">
                    <select
                      value={subject.grade}
                      onChange={(e) => updateSubject(subject.id, 'grade', Number(e.target.value))}
                      className="w-full px-3 py-2 border border-gray-200 rounded-md focus:ring-2 focus:ring-teal-500 focus:outline-none bg-white"
                    >
                      <option value={4.0}>A (4.0)</option>
                      <option value={3.5}>B+ (3.5)</option>
                      <option value={3.0}>B (3.0)</option>
                      <option value={2.5}>C+ (2.5)</option>
                      <option value={2.0}>C (2.0)</option>
                      <option value={1.5}>D+ (1.5)</option>
                      <option value={1.0}>D (1.0)</option>
                      <option value={0.0}>F (0.0)</option>
                    </select>
                  </div>
                  <button 
                    onClick={() => removeSubject(subject.id)}
                    className="p-2 text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="p-4 border-t border-gray-200 bg-gray-50">
             <Button onClick={addSubject} variant="secondary" className="w-full border-dashed border-2 text-gray-500 hover:text-teal-600 hover:border-teal-300">
               <Plus className="w-5 h-5 mr-2" /> ເພີ່ມວິຊາ
             </Button>
          </div>
        </div>

        {/* GPA Result Card */}
        <div className="w-full lg:w-80">
          <div className="bg-gradient-to-br from-teal-500 to-emerald-600 rounded-2xl shadow-lg p-8 text-white text-center sticky top-6">
            <h3 className="text-teal-100 font-medium mb-2">ຄະແນນສະເລ່ຍຂອງທ່ານ</h3>
            <div className="text-6xl font-bold tracking-tight mb-4">{gpa}</div>
            <div className="grid grid-cols-2 gap-4 text-sm bg-white/10 rounded-lg p-4">
              <div className="flex flex-col">
                <span className="text-teal-100">ໜ່ວຍກິດລວມ</span>
                <span className="font-semibold text-xl">
                  {subjects.reduce((sum, s) => sum + s.credit, 0)}
                </span>
              </div>
              <div className="flex flex-col border-l border-white/20">
                <span className="text-teal-100">ຈຳນວນວິຊາ</span>
                <span className="font-semibold text-xl">{subjects.length}</span>
              </div>
            </div>
            
            <div className="mt-6 text-xs text-teal-200">
               *ການຄິດໄລ່ອ້າງອີງຕາມລະບົບ 4.00 ມາດຕະຖານ
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
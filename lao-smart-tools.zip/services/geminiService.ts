import { GoogleGenAI, Type } from "@google/genai";
import { TodoItem } from '../types';

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

/**
 * Summarizes text with a specific style/length focus.
 * Now supports Thinking Mode for deeper analysis.
 */
export const summarizeText = async (text: string, mode: 'short' | 'bullet' | 'detail', useThinking: boolean = false): Promise<string> => {
  if (!text.trim()) return '';
  
  let prompt = '';
  switch (mode) {
    case 'short':
      prompt = 'ສະຫຼຸບຂໍ້ຄວາມນີ້ໃຫ້ສັ້ນກະທັດຮັດ ເຂົ້າໃຈງ່າຍ ໃນ 1 ວັກ (Summarize this concisely in 1 paragraph in Lao):';
      break;
    case 'bullet':
      prompt = 'ສະຫຼຸບປະເດັນສຳຄັນຂອງຂໍ້ຄວາມນີ້ເປັນຂໍ້ໆ (Summarize key points in bullet points in Lao):';
      break;
    case 'detail':
      prompt = 'ສະຫຼຸບໃຈຄວາມສຳຄັນຢ່າງລະອຽດ ຄົບຖ້ວນ (Summarize in detail covering all main points in Lao):';
      break;
  }

  try {
    const modelId = useThinking ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
    const config: any = {};
    
    if (useThinking) {
      config.thinkingConfig = { thinkingBudget: 32768 };
      // Do not set maxOutputTokens when using thinking
    }

    const response = await ai.models.generateContent({
      model: modelId,
      contents: `${prompt}\n\n${text}`,
      config
    });
    return response.text || 'ບໍ່ສາມາດສ້າງຄຳຕອບໄດ້';
  } catch (error) {
    console.error("Summarize Error:", error);
    return 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ກັບ AI';
  }
};

/**
 * Generates a checklist from a topic/goal using JSON schema.
 */
export const generateChecklist = async (topic: string): Promise<TodoItem[]> => {
  if (!topic.trim()) return [];

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `ສ້າງລາຍການສິ່ງທີ່ຕ້ອງເຮັດ (Checklist) ສຳລັບຫົວຂໍ້: "${topic}". ຕອບກັບເປັນ JSON array ຂອງ strings ເທົ່ານັ້ນ ພາສາລາວ`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING
          }
        }
      }
    });

    const rawItems: string[] = JSON.parse(response.text || '[]');
    
    return rawItems.map(text => ({
      id: crypto.randomUUID(),
      text,
      completed: false
    }));

  } catch (error) {
    console.error("Checklist Gen Error:", error);
    return [];
  }
};

/**
 * Universal content converter (Text/Code/File transformation).
 * Supports Thinking Mode and File Inputs.
 */
export const convertContent = async (
  text: string, 
  file: { data: string; mimeType: string } | null,
  instruction: string,
  useThinking: boolean = false
): Promise<string> => {
  if (!text.trim() && !file) return '';

  try {
    const modelId = useThinking ? 'gemini-3-pro-preview' : 'gemini-3-flash-preview';
    const config: any = {};
    
    if (useThinking) {
      config.thinkingConfig = { thinkingBudget: 32768 };
    }

    const parts = [];
    if (file) {
      parts.push({
        inlineData: {
          data: file.data,
          mimeType: file.mimeType
        }
      });
    }
    if (text) {
      parts.push({ text });
    }
    
    parts.push({ text: `ຄຳສັ່ງ: ${instruction} (ຕອບເປັນພາສາລາວ ຖ້າເໝາະສົມ)` });

    const response = await ai.models.generateContent({
      model: modelId,
      contents: { parts },
      config
    });
    return response.text || 'ບໍ່ສາມາດແປງຂໍ້ມູນໄດ້';
  } catch (error) {
    console.error("Converter Error:", error);
    return 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ກັບ AI';
  }
};

/**
 * Transcribes audio using Gemini 3 Flash.
 */
export const transcribeAudio = async (audioData: string, mimeType: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: audioData,
              mimeType: mimeType,
            },
          },
          {
            text: "Transcribe this audio to text. If it is in Lao or Thai, use the respective language script. If mixed, maintain the languages. Prioritize Lao script if unclear.",
          },
        ],
      },
    });
    return response.text || 'ບໍ່ສາມາດຖອດຄວາມສຽງໄດ້';
  } catch (error) {
    console.error("Transcribe Error:", error);
    return 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ກັບ AI';
  }
};

/**
 * Transcribes video to text with optional translation.
 */
export const transcribeVideo = async (videoData: string, mimeType: string, targetLanguage: string): Promise<string> => {
  try {
    let prompt = "Transcribe the speech from this video clearly.";
    
    if (targetLanguage !== 'Original') {
      prompt += ` Then, translate the transcription directly into ${targetLanguage} (Language: ${targetLanguage}). Return ONLY the translated text.`;
    } else {
      prompt += " If the audio is mixed language, transcribe exactly what is said. Identify speakers if possible. Support Lao language.";
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: videoData,
              mimeType: mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
      },
    });
    return response.text || 'ບໍ່ສາມາດຖອດຄວາມວິດີໂອໄດ້';
  } catch (error) {
    console.error("Video Transcribe Error:", error);
    return 'ເກີດຂໍ້ຜິດພາດໃນການເຊື່ອມຕໍ່ກັບ AI ຫຼື ໄຟລ໌ວິດີໂອມີຂະໜາດໃຫຍ່ເກີນໄປ';
  }
};
